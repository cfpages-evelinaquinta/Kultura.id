Oxygen. Copyright © Soflyy. All Rights Reserved.

The Oxygen PHP/JS/HTML/CSS code inside the `plugin` folder created by Soflyy is licensed under the GPL v2/GPL v3 as applicable. 3rd party code is licensed under the applicable license and is used by Oxygen with permission. See `plugin/license.md` for details.

The Oxygen JavaScript code in the `builder` folder is licensed under the terms of your purchase. We plan to release this code under an open source license if Font Awesome will let us, or when we change icon sets.

Code from 3rd party vendors is licensed under the applicable license terms. See `license.md` in the `plugin` folder for more details.
