<?php

namespace Breakdance\Themeless\ThemeDisabler;

require_once __DIR__ . '/theme-disabler-settings-tab.php';
require_once __DIR__ . '/theme-disabler.php';
require_once __DIR__ . '/theme-support.php';
