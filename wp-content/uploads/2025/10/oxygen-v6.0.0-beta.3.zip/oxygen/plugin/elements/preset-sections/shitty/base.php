<?php

require_once __DIR__ . "/dumbfuck_column_layout.php";
require_once __DIR__ . "/dumbfuck_section_layout.php";
