<?php

require_once __DIR__ . "/shitty/base.php";

require_once __DIR__ . "/effects.php";
require_once __DIR__ . "/typography.php";
require_once __DIR__ . "/borders.php";
require_once __DIR__ . "/borders_without_shadows.php";
require_once __DIR__ . "/size.php";
require_once __DIR__ . "/layout.php";
require_once __DIR__ . "/spacing.php";
require_once __DIR__ . "/layout_basic_flex.php";
require_once __DIR__ . "/simple_layout.php";
require_once __DIR__ . "/grid.php";
require_once __DIR__ . "/background_fancy.php";
require_once __DIR__ . "/combined-design.php";
require_once __DIR__ . "/form.php";
require_once __DIR__ . "/lightbox.php";
require_once __DIR__ . "/atoms/atomv1button.php";
require_once __DIR__ . "/atoms/atomv1custombutton.php";
require_once __DIR__ . "/atoms/atomv1icon.php";
require_once __DIR__ . "/woo/base.php";
require_once __DIR__ . "/shape/shape.php";
require_once __DIR__ . "/atoms/atomV1Swiper.php";
require_once __DIR__ . "/filter.php";
require_once __DIR__ . "/tabs.php";
require_once __DIR__ . "/atoms/atomv1form.php";
require_once __DIR__ . "/atoms/atomv1menu.php";
require_once __DIR__ . "/custom_css.php";
