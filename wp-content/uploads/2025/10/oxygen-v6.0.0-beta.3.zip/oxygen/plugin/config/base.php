<?php

namespace Breakdance\Config;

require_once __DIR__ . '/breakpoints.php';
require_once __DIR__ . '/builtin-breakpoints.php';
