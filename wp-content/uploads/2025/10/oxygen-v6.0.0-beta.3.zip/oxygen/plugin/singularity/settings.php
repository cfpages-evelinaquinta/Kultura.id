<?php

namespace Breakdance\FutureLayer;

/**
 * @return array
 */
function getFutureLayerSettings()
{
    return [
        'homepageId' => (int) get_option('page_on_front', 0)
    ];
}
