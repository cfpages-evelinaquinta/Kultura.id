<?php

namespace Breakdance\Singularity;

require_once __DIR__ . "/endpoints/pages.php";
require_once __DIR__ . "/endpoints/website-intake-service.php";
require_once __DIR__ . "/endpoints/wp-menu.php";
require_once __DIR__ . "/endpoints/handle-step-1.php";
require_once __DIR__ . "/endpoints/brand.php";
require_once __DIR__ . "/endpoints/download-image.php";
require_once __DIR__ . "/endpoints/set-as-homepage.php";
require_once __DIR__ . "/endpoints/header-and-footer-blocks.php";
require_once __DIR__ . "/ai-server.php";
require_once __DIR__ . "/settings.php";
