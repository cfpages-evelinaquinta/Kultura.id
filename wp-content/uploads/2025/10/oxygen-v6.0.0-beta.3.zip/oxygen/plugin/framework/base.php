<?php

require_once __DIR__ . '/database/schema.functions.php';
