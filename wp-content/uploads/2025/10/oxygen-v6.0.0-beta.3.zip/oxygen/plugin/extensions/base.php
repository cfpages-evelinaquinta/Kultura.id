<?php

require __DIR__ . '/controller.php';
require __DIR__ . '/settings-page.php';
