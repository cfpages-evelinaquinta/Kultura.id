<?php

namespace Breakdance\Admin\SettingsPage;

class SettingsPageController
{

    use \Breakdance\Singleton;

    /**
     * @var array{name:string,slug:string,order:int}[]
     */
    public $tabs = [];

}
