<?php

namespace Breakdance\AJAX;

require_once __DIR__ . "/ajax_at_any_url.php";
require_once __DIR__ . "/api.php";
require_once __DIR__ . "/endpoints/base.php";
