<?php

namespace Breakdance\AjaxEndpoints;

require_once __DIR__ . "/document-chooser.php";
require_once __DIR__ . "/post-chooser.php";
require_once __DIR__ . "/menu-chooser.php";
require_once __DIR__ . "/get-taxonomies.php";
require_once __DIR__ . "/get-post-types.php";
require_once __DIR__ . "/get-editable-post-types.php";
require_once __DIR__ . "/get-popups.php";
require_once __DIR__ . "/get-acf-breakdance-content-fields.php";
require_once __DIR__ . "/get-acf-fields.php";
require_once __DIR__ . "/get-metabox-fields.php";
require_once __DIR__ . "/get-acf-relationship-fields.php";
require_once __DIR__ . "/insert-post.php";
require_once __DIR__ . "/manage-onboarding-pages.php";
