<?php

namespace Breakdance\Fonts;

class Consts
{
    // https://github.com/khoben/gfont-previews/blob/master/output/google.json
    public const GOOGLE_FONT_FILE = __DIR__ . '/google-font-list.json';
}
