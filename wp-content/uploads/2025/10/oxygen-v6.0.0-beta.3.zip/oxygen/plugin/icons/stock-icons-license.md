FontAwesome 5 Free - Font Awesome Free 5.15.1 by @fontawesome - https://fontawesome.com
License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
IcoMoon Free - https://icomoon.io/app/#/select/library / https://creativecommons.org/licenses/by/4.0/
