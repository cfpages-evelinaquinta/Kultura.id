<?php

require_once __DIR__ . '/functions.php';

require_once __DIR__ . '/ajax-api/find_icons.php';

require_once __DIR__ . '/ajax-api/get_icon_sets.php';

require_once __DIR__ . '/ajax-api/delete_icon_set.php';

require_once __DIR__ . '/ajax-api/delete_icon.php';

require_once __DIR__ . '/ajax-api/upload_icons.php';

require_once __DIR__ . '/ajax-api/export_icon_set.php';
